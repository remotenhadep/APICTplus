<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Tymon\JWTAuth\Facades\JWTAuth;

class ApiController extends Controller
{    
    /**
     * @OA\Post(
     *     path="/api/register",
     *     operationId="register",
     *     tags={"Authentication"},
     *     summary="User Register",
     *     description="User register and JWT token generation",
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             required={"phone","password","name"},
     *             @OA\Property(property="phone", type="string", format="text"),
     *             @OA\Property(property="password", type="string", format="password"),
     *             @OA\Property(property="name", type="string", format="text"),
     *         ),
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Successful register with JWT token",
     *         @OA\JsonContent(
     *             @OA\Property(property="code", type="string"),
     *             @OA\Property(property="error", type="string"),
     *             @OA\Property(property="data", type="array", @OA\Items(
     *                  @OA\Property(property="account", type="array", 
     *                  @OA\Items(
     *                      @OA\Property(property="name", type="string"),      
     *                      @OA\Property(property="token", type="string")
    *                    ))
    *              ))
     *         )
     *     )
     * )
     */
    public function register(Request $req){
        $phone = $req->input('phone');
        $pass = $req->input('password');
        $name = $req->input('name');
        if ($name == null) {
            $name = "";
        }
        if ($phone == null || $pass == null) {
            return [
                'code' => "401",
                'error'=>"Null parameter",
                'data'=>[
                    'list'=>[]
                ]
            ];
        }
        $accexits = Account::where('email',$phone)->first();
        if ($accexits != null) {
            # code...
            return [
                'code' => "402",
                'error'=>"Account is exits",
                'data'=>[
                    'list'=>[]
                ]
            ];
        }
        $token = Crypt::encryptString($phone.'-'.$pass);
        $acc = new Account();
        $acc->phone = '';
        $acc->password = Crypt::encryptString($pass);
        $acc->email=$phone;
        $acc->name=$name;
        $acc->token=$token;
        $acc->google='';
        $acc->facebook='';
        $acc->status=1;
        $acc->save();
        return [
            'code' => "200",
            'error'=>"",
            'data'=>[
                'account'=>['name'=>$name,'token'=>$token]
            ]
        ];
    }

    /**
     * @OA\Post(
     *     path="/api/login",
     *     operationId="login",
     *     tags={"Authentication"},
     *     summary="User login",
     *     description="User login and JWT token generation",
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             required={"email","password"},
     *             @OA\Property(property="phone", type="string", format="text"),
     *             @OA\Property(property="password", type="string", format="password")
     *         ),
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Successful login with JWT token",
     *         @OA\JsonContent(
     *             @OA\Property(property="access_token", type="string"),
     *             @OA\Property(property="token_type", type="string"),
     *             @OA\Property(property="expires_in", type="integer")
     *         )
     *     ),
     *     @OA\Response(
     *         response=401,
     *         description="Unauthorized"
     *     )
     * )
     */
    public function login(Request $request){

        // Validation
        $request->validate([
            "phone" => "required",
            "password" => "required"
        ]);

        $token = auth()->attempt([
            "email" => $request->phone,
            "password" => $request->password
        ], true);

        if(!$token){

            return response()->json([
                "status" => false,
                "message" => "Invalid login details"
            ]);
        }

        return response()->json([
            "status" => true,
            "message" => "User logged in succcessfully",
            "token" => $token,
            //"expires_in" => auth()->factory()->getTTL() * 60
        ]);
    }
}
